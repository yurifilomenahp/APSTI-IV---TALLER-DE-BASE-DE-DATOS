<?php
session_start();
require_once "conexion.php";

function volver($mensaje) {
    $_SESSION["mensaje"] = $mensaje;
    header("Location: index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

if (!hash_equals($_SESSION["csrf_token"] ?? "", $_POST["csrf_token"] ?? "")) {
    volver("La solicitud no es válida. Vuelve a intentarlo.");
}

$dni = trim($_POST["dni"] ?? "");

if (!preg_match('/^[0-9]{8}$/', $dni)) {
    volver("Ingresa un DNI válido de 8 dígitos.");
}

$consulta = $conexion->prepare("DELETE FROM usuarios WHERE dni = ?");
$consulta->bind_param("s", $dni);
$consulta->execute();

if ($consulta->affected_rows > 0) {
    volver("El usuario fue eliminado correctamente.");
}

volver("No se encontró un usuario con ese DNI.");
?>
