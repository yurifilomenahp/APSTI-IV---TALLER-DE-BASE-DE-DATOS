<?php
session_start();
require_once "conexion.php";

function volver($mensaje) {
    $_SESSION["mensaje"] = $mensaje;
    header("Location: index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

if (!hash_equals($_SESSION["csrf_token"] ?? "", $_POST["csrf_token"] ?? "")) {
    volver("La solicitud no es válida. Vuelve a intentarlo.");
}

$dni = trim($_POST["dni"] ?? "");
$nombres = trim($_POST["nombres"] ?? "");
$apellidos = trim($_POST["apellidos"] ?? "");

if (!preg_match('/^[0-9]{8}$/', $dni) || $nombres === "" || $apellidos === "") {
    volver("Verifica el DNI, los nombres y los apellidos.");
}

$consulta = $conexion->prepare(
    "UPDATE usuarios SET nombres = ?, apellidos = ? WHERE dni = ?"
);
$consulta->bind_param("sss", $nombres, $apellidos, $dni);
$consulta->execute();

if ($consulta->affected_rows > 0) {
    volver("Los datos del usuario fueron actualizados correctamente.");
} elseif ($consulta->affected_rows === 0) {
    volver("No se realizaron cambios. Comprueba que el DNI exista y que los datos sean diferentes.");
} else {
    volver("No se pudo actualizar el usuario.");
}
?>
