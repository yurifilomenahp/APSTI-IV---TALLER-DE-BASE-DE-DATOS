<?php
// Conexión a MySQL. En XAMPP normalmente el usuario es root y no tiene contraseña.
$host = "localhost";
$usuario = "root";
$password = "";
$base_datos = "gestion_usuarios";

$conexion = new mysqli($host, $usuario, $password, $base_datos);

if ($conexion->connect_error) {
    die("Error de conexión con la base de datos: " .
        htmlspecialchars($conexion->connect_error, ENT_QUOTES, "UTF-8"));
}

$conexion->set_charset("utf8mb4");
?>
