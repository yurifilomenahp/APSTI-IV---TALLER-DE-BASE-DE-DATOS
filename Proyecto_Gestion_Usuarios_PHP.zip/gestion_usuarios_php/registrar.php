<?php
session_start();
require_once "conexion.php";

function volver($mensaje, $tipo = "info") {
    $_SESSION["mensaje"] = $mensaje;
    $_SESSION["tipo_mensaje"] = $tipo;
    header("Location: index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

if (!hash_equals($_SESSION["csrf_token"] ?? "", $_POST["csrf_token"] ?? "")) {
    volver("La solicitud no es válida. Vuelve a intentarlo.", "error");
}

$nombres = trim($_POST["nombres"] ?? "");
$apellidos = trim($_POST["apellidos"] ?? "");
$dni = trim($_POST["dni"] ?? "");
$contrasena = $_POST["contrasena"] ?? "";

if ($nombres === "" || $apellidos === "" ||
    !preg_match('/^[0-9]{8}$/', $dni) || strlen($contrasena) < 6) {
    volver("Completa los campos correctamente. El DNI debe tener 8 dígitos y la contraseña al menos 6 caracteres.", "error");
}

$hash = password_hash($contrasena, PASSWORD_DEFAULT);
$consulta = $conexion->prepare(
    "INSERT INTO usuarios (nombres, apellidos, dni, password_hash)
     VALUES (?, ?, ?, ?)"
);
$consulta->bind_param("ssss", $nombres, $apellidos, $dni, $hash);

if ($consulta->execute()) {
    volver("Usuario registrado correctamente.", "ok");
}

if ($conexion->errno === 1062) {
    volver("Ese DNI ya se encuentra registrado.", "error");
}

volver("No se pudo registrar el usuario. Revisa los datos e inténtalo nuevamente.", "error");
?>
