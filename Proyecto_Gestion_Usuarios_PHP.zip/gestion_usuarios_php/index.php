<?php
session_start();
require_once "conexion.php";

function h($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, "UTF-8");
}

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$mensaje = $_SESSION["mensaje"] ?? "";
$tipo_mensaje = $_SESSION["tipo_mensaje"] ?? "info";
unset($_SESSION["mensaje"], $_SESSION["tipo_mensaje"]);

$usuario_encontrado = null;
$hora_pais = null;
$error_hora = "";
$error_busqueda = "";

$paises = [
    "Perú" => "America/Lima",
    "Colombia" => "America/Bogota",
    "Chile" => "America/Santiago",
    "Argentina" => "America/Argentina/Buenos_Aires",
    "México" => "America/Mexico_City",
    "España" => "Europe/Madrid",
    "Estados Unidos (Nueva York)" => "America/New_York"
];

$dni_busqueda = trim($_GET["dni"] ?? "");
$pais_seleccionado = $_GET["pais"] ?? "Perú";

if (isset($_GET["buscar"])) {
    if (!preg_match('/^[0-9]{8}$/', $dni_busqueda)) {
        $error_busqueda = "Ingresa un DNI válido de exactamente 8 dígitos.";
    } elseif (!array_key_exists($pais_seleccionado, $paises)) {
        $error_busqueda = "Selecciona un país válido.";
    } else {
        $consulta = $conexion->prepare(
            "SELECT nombres, apellidos, dni, fecha_registro
             FROM usuarios WHERE dni = ? LIMIT 1"
        );
        $consulta->bind_param("s", $dni_busqueda);
        $consulta->execute();
        $resultado = $consulta->get_result();
        $usuario_encontrado = $resultado->fetch_assoc();
        $consulta->close();

        if (!$usuario_encontrado) {
            $error_busqueda = "No se encontró un usuario con ese DNI.";
        } else {
            // La hora se obtiene de un servicio externo; no se calcula manualmente.
            $zona_horaria = $paises[$pais_seleccionado];
            $url_api = "https://worldtimeapi.org/api/timezone/" . rawurlencode($zona_horaria);
            $contexto = stream_context_create([
                "http" => [
                    "method" => "GET",
                    "timeout" => 6,
                    "header" => "Accept: application/json\r\n"
                ]
            ]);

            $respuesta_api = @file_get_contents($url_api, false, $contexto);
            if ($respuesta_api !== false) {
                $datos_api = json_decode($respuesta_api, true);
                if (is_array($datos_api) && !empty($datos_api["datetime"])) {
                    try {
                        $fecha_api = new DateTime($datos_api["datetime"]);
                        $hora_pais = $fecha_api->format("d/m/Y H:i:s");
                    } catch (Exception $e) {
                        $error_hora = "El servicio respondió, pero no se pudo interpretar la fecha.";
                    }
                } else {
                    $error_hora = "El servicio de hora no devolvió información válida.";
                }
            } else {
                $error_hora = "No se pudo consultar la hora. Verifica tu conexión a Internet e inténtalo nuevamente.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios</title>
    <?php if ($usuario_encontrado): ?>
    <link rel="stylesheet" href="css/resultado.css">
    <?php endif; ?>
</head>
<body>
    <h1>Gestión de Usuarios</h1>

    <?php if ($mensaje !== ""): ?>
        <p><?php echo h($mensaje); ?></p>
    <?php endif; ?>

    <h2>Registrar usuario</h2>
    <form action="registrar.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo h($_SESSION["csrf_token"]); ?>">

        <label for="nombres">Nombres:</label>
        <input type="text" id="nombres" name="nombres" maxlength="100" required>
        <br><br>

        <label for="apellidos">Apellidos:</label>
        <input type="text" id="apellidos" name="apellidos" maxlength="100" required>
        <br><br>

        <label for="dni_registro">DNI (8 dígitos):</label>
        <input type="text" id="dni_registro" name="dni" pattern="[0-9]{8}"
               minlength="8" maxlength="8" inputmode="numeric"
               title="El DNI debe tener exactamente 8 números." required>
        <br><br>

        <label for="contrasena">Contraseña:</label>
        <input type="password" id="contrasena" name="contrasena" minlength="6" required>
        <br><br>

        <button type="submit">Registrar</button>
    </form>

    <hr>

    <h2>Actualizar usuario</h2>
    <form action="actualizar.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo h($_SESSION["csrf_token"]); ?>">

        <label for="dni_actualizar">DNI del usuario a actualizar:</label>
        <input type="text" id="dni_actualizar" name="dni" pattern="[0-9]{8}"
               minlength="8" maxlength="8" inputmode="numeric" required>
        <br><br>

        <label for="nombres_nuevos">Nuevos nombres:</label>
        <input type="text" id="nombres_nuevos" name="nombres" maxlength="100" required>
        <br><br>

        <label for="apellidos_nuevos">Nuevos apellidos:</label>
        <input type="text" id="apellidos_nuevos" name="apellidos" maxlength="100" required>
        <br><br>

        <button type="submit">Actualizar</button>
    </form>

    <hr>

    <h2>Eliminar usuario</h2>
    <form action="eliminar.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo h($_SESSION["csrf_token"]); ?>">

        <label for="dni_eliminar">DNI del usuario a eliminar:</label>
        <input type="text" id="dni_eliminar" name="dni" pattern="[0-9]{8}"
               minlength="8" maxlength="8" inputmode="numeric" required>
        <br><br>

        <button type="submit">Eliminar</button>
    </form>

    <hr>

    <h2>Buscar usuario</h2>
    <form action="index.php" method="GET">
        <label for="dni_buscar">DNI:</label>
        <input type="text" id="dni_buscar" name="dni" pattern="[0-9]{8}"
               minlength="8" maxlength="8" inputmode="numeric"
               value="<?php echo h($dni_busqueda); ?>" required>
        <br><br>

        <label for="pais">País para mostrar la hora:</label>
        <select id="pais" name="pais">
            <?php foreach ($paises as $nombre_pais => $zona): ?>
                <option value="<?php echo h($nombre_pais); ?>"
                    <?php echo ($pais_seleccionado === $nombre_pais) ? "selected" : ""; ?>>
                    <?php echo h($nombre_pais); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br><br>

        <button type="submit" name="buscar" value="1">Buscar</button>
    </form>

    <?php if ($error_busqueda !== ""): ?>
        <p><?php echo h($error_busqueda); ?></p>
    <?php endif; ?>

    <?php if ($usuario_encontrado): ?>
        <section class="resultado-usuario">
            <h2>USUARIO ENCONTRADO</h2>
            <p><strong>Nombres:</strong> <?php echo h($usuario_encontrado["nombres"]); ?></p>
            <p><strong>Apellidos:</strong> <?php echo h($usuario_encontrado["apellidos"]); ?></p>
            <p><strong>DNI:</strong> <?php echo h($usuario_encontrado["dni"]); ?></p>
            <p><strong>País:</strong> <?php echo h($pais_seleccionado); ?></p>
            <?php if ($hora_pais !== null): ?>
                <p><strong>Hora actual:</strong> <?php echo h($hora_pais); ?></p>
            <?php else: ?>
                <p><?php echo h($error_hora); ?></p>
            <?php endif; ?>
        </section>
    <?php endif; ?>
</body>
</html>
