PROYECTO: GESTIÓN DE USUARIOS
Tecnologías: PHP + MySQL + XAMPP + phpMyAdmin.

ARCHIVOS
- index.php: pantalla principal y búsqueda.
- conexion.php: conexión a MySQL.
- registrar.php: registra usuarios.
- actualizar.php: modifica nombres y apellidos.
- eliminar.php: elimina usuarios.
- database.sql: crea la base de datos y la tabla.
- css/resultado.css: personaliza únicamente el panel del usuario encontrado.
- js/README.txt: explica por qué no se usa JavaScript en los formularios.

INSTALACIÓN EN XAMPP
1. Instala e inicia Apache y MySQL desde el panel de XAMPP.
2. Copia la carpeta gestion_usuarios_php dentro de C:\xampp\htdocs\
   Puedes cambiarle el nombre a gestion_usuarios.
3. Abre http://localhost/phpmyadmin
4. Entra a la pestaña Importar y selecciona database.sql.
5. Ejecuta la importación. Se creará la base de datos gestion_usuarios.
6. Abre http://localhost/gestion_usuarios/
   (usa el nombre real que le hayas puesto a la carpeta).
7. Registra un usuario de prueba con un DNI de 8 números.
8. Prueba buscarlo, actualizarlo y eliminarlo.

CONFIGURACIÓN
En conexion.php se usa:
- Servidor: localhost
- Usuario: root
- Contraseña: vacía
- Base de datos: gestion_usuarios
Si tu MySQL tiene otra contraseña, cámbiala en conexion.php.

HORA POR PAÍS
Al buscar un usuario se consulta WorldTimeAPI mediante PHP.
La hora no se calcula manualmente ni está escrita fija en el código.
Se necesita conexión a Internet y que PHP permita solicitudes HTTPS salientes.
Si el servicio no responde, el sistema muestra un aviso y no inventa la hora.

SEGURIDAD
- El DNI se valida con exactamente 8 dígitos.
- Las consultas usan sentencias preparadas para evitar inyección SQL.
- La contraseña se guarda con password_hash; nunca se almacena como texto visible.
- Se escapan los datos al mostrarlos en HTML.

NOTA
El examen permite PHP/Python/Java/SQL. Esta solución usa PHP y MySQL, de acuerdo con la estructura PHP mostrada en la hoja 8 y el uso de phpMyAdmin.
